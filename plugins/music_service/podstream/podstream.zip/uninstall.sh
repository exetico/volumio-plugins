#!/bin/bash

echo "Uninstalling podstream dependencies"
sudo rm -Rf /data/configuration/music_service/podstream/
sudo rm -Rf /data/plugins/music_service/podstream/
echo "Removing podstream"
echo " Removing podstream configuration file"

echo "Done"
echo "pluginuninstallend"
