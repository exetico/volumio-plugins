#!/bin/bash
PLFOLDER="/data/playlist"
TEMPLATE="volumio.xsl"
PLUGINDIR="/data/plugins/music_service/podstream"


#download rss feeds
while read p; do
  echo "${p%;*}"
  echo "${p##*;}"
  sudo wget "${p##*;}" -O "${p%;*}".rss      
done <"$PLUGINDIR"/"rssfeeds"


#convert rss feeds to playlist
shopt -s nullglob
for f in *.rss
do
  filename=$(basename "$f")
  filename="${filename%.*}"
  echo "Converting rss file - $f"
  sudo xsltproc -o "$PLFOLDER"/"$filename" "$TEMPLATE" "$f"
  sudo rm "$filename".rss
done 
