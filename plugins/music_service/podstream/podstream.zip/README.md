[![GitHub version](https://badge.fury.io/gh/exetico%2Fvolumio-plugins.svg)](https://badge.fury.io/gh/exetico%2Fvolumio-plugins)

# Stream Podcasts on Volumio (Create playlist with rss-feeds)
This is in a very early state, but you are welcome to look into how it looks.

## To-do:
- Create .timer for the .service, so it's triggered every 2. hours fx.
- Allow the user to edit the frequency of the update-interval (on hour-basis) in the Volumio-configs
- Look into a easy way to handle the rssfeed-stuff. Should i go with an table-kinda thing? (I can't find anything like this, in the Volumio GUI at the moment), or should i go with an simple solution like allowing to referate to an pastebin-file or something like that?

## Credits
- Thanks to volspotconnect for the structure of the solution. I couldnt' find out how is was working.
- Thanks to buzink for the original podcast-playlist structure, idea and solution (It's now hardly changed, cleaned up, and multiple options is removed)